module.exports = async function (context, req) {
    context.log('Working test function processed a request.');
    
    return {
        status: 200,
        body: "Working test function is working!"
    };
};